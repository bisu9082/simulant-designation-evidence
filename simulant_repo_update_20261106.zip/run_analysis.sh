#!/bin/sh
# 분석 파이프라인 정본 (2026-10-13 신설).
#
# 왜 필요한가. 이 프로젝트의 재발 결함은 계산 오류가 아니라 전파 실패였다.
# 서술자 정의를 바꾸면 그것을 읽는 하위 산출물을 전부 다시 만들어야 하는데,
# 순서가 머릿속에만 있었으므로 매번 몇 단계가 빠졌다. GATE 8 3차에서 지적된
# 도판-본문 불일치, 검증기가 들고 있던 낡은 p 값, outputs/ 와 paper/ 의 도판
# 시차가 모두 이 경로다. 순서를 파일로 고정한다.
#
# 2026-10-15 보강. 저장소를 빈 outputs/ 로 클론해 돌려 보니 두 가지가 빠져
# 있었다. match_by_panel.json 은 어떤 스크립트도 만들지 않는 고아 파일이었고
# (표 3·도판 2a·검증 사실 12건의 출처), 독성축 체인 전체가 이 목록에 없어
# 도판 생성과 검증이 FileNotFoundError 로 멈췄다. 둘 다 아래에 넣었다.
#
# 의존 순서 (패널·순열 축):
#   analysis_main        정본 공간 정의 -> experiment_summary.json, distance_table
#   perm_sidedness       단측/양측 p (verify_consistency 의 사실표가 읽는다)
#   sanity_checks        순열 귀무분포 .npy (도판 (d) 가 읽는다)
#   analyze_electronic   전자공간 단독 분석
#   normalize_nn         정규화 최근접 거리표
#   perm_statistics      패널 2종 x 통계량 6종
#   deltaE_premise       측정 배열 전제 검정
#   deltaE_power         Fisher 통합 + 검정력
#   rollback_c           방향 C 전용 (omega 종속, 차원 통제, Mantel, 중심화 바닥)
#   match_by_panel       패널 3구성 x 작용제 11종 최근접 모사체와 유효매칭
#   mde                  최소검출효과 — 음성 결과가 검정력 부족이 아님을 보인다
#   blockbalance         구조38 대 전자3 블록 가중 민감도 (SI res:blockbalance)
#   stat_supplement(2)   보정 체계 5종, 백색화 통제, WY minP, 서술자 부트스트랩
#
# 의존 순서 (독성축, Supplementary):
#   parse_aegl           EPA 원문(sources/) 파싱 -> toxicity_aegl.csv
#   build_tox_trainset   훈련집합 조립
#   validate_identity    화학적 동일성 검사 -> identity_validation.json.
#                        cwa_registry 가 이 파일에서 제외 레코드를 읽으므로
#                        qsar_tox 보다 반드시 먼저 와야 한다. FAIL 2건은
#                        원고가 보고한 제외 레코드이므로 비정상 종료를 허용한다.
#   qsar_tox             랜덤포레스트 + 적용영역 -> qsar_tox_summary.json, qsar_oof
#   h1_decoupling        충실도-안전 탈동조 -> h1_summary.json, h1_candidates
#   h1_screen_sensitivity 타당성심사 민감도 -> h1_screen_sensitivity.json
#   minority_regression  꼬리 회귀 진단 (qsar_oof 를 읽는다)
#   validate_aegl_parse  이중 판독 대조
#
# xtb_fast 는 이 목록에 없다. AEGL 230종에 GFN2-xTB 를 다시 돌리는 단계이고
# xtb 바이너리가 필요하다. 산출물 aegl_electronic.csv 와 xtb_fast_vs_slow.csv
# 는 저장소에 포함해 두었으므로 하위 단계가 그대로 돌아간다.
#
# 사용: sh run_analysis.sh && sh build_paper_acs.sh --figs && python3 verify_consistency.py
set -e
cd "$(dirname "$0")"

run_strict() {
  for s in "$@"; do
    printf '[run] %-22s ' "$s"
    # 2026-11-06 (9차). 항목이 인자를 가질 수 있게 했다. order_invariance 는
    # --n 40 을 넘겨야 예치본과 같은 결과가 나온다. $s 를 일부러 따옴표 없이
    # 둬서 낱말 분리가 일어나게 하고, 로그 이름은 첫 낱말에서만 뽑는다.
    # 목록은 이 파일 안에서만 정해지므로 외부 입력이 섞일 여지가 없다.
    _prog=${s%% *}
    # shellcheck disable=SC2086
    if python3 $s > "outputs/_log_${_prog%.py}.txt" 2>&1; then
      echo ok
    else
      echo FAIL
      tail -20 "outputs/_log_${_prog%.py}.txt"
      exit 1
    fi
  done
}

# 서술자 재현 관문 (2026-10-25 신설). 3D 서술자가 코드에서 재생성되지 않으면
# 그 아래 모든 거리가 배포 CSV 에만 존재하는 값이 된다. 여기서 막는다.
if ! python3 build_descriptors.py --verify; then
  echo "[중단] 서술자 재현 관문 미통과"; exit 1
fi

# 패널·순열 축
run_strict analysis_main.py perm_sidedness.py sanity_checks.py \
           analyze_electronic.py normalize_nn.py perm_statistics.py \
           deltaE_premise.py mantel_power.py deltaE_power.py rollback_c.py match_by_panel.py \
           mde.py blockbalance.py pesticide_panel.py pesticide_family.py stat_supplement.py stat_supplement2.py nearest_agent_boot.py null_match_expectation.py \
           match_by_panel_ascl3.py dft_electronic_space.py \
           subspace_null.py deltaE_extended.py lewisite_isomer.py

# 2026-11-02 (T2). 다섯 스크립트를 파이프라인에 넣는다. 전부 원고가 인용하는
# 예치물을 만들며, 목록에 없으면 빈 outputs/ 로 클론했을 때 검증기의 G-D
# 가드(인용된 예치물에 생성기가 있는가)에서 멈춘다.
#   order_invariance       상관필터의 열 순서 의존성. 구판/신판 분포 대조
#   match_rule_audit       매칭 둘째 조건의 두 판독 (넓은/좁은) 대조
#   deltaE_noise           응답 크기, 잡음 바닥 가용성, 농도-SNR 교란
#   purity_sensitivity     루이사이트 순도 67% 민감도
#   channel_classification 선언 29채널 대 유효 23채널의 분류 성능
# order_invariance 는 치환 40회 x 패널 3종 x 규칙 2종이라 약 20분 걸린다.
#   multiplicity_panels    구성 4개 x 공간 3종 x 통계량 6종 = 72검정 BH
#                          2026-11-03: T0-6 에서 스크립트만 만들고 이 목록에
#                          넣지 않아, T2-1 의 필터 교체가 이 예치물에
#                          전파되지 않았다. 리뷰어가 구판 p 를 찾아냈다.
#   shape_reduction        관성텐서 파생 좌표 축소 민감도 (작업 A-1).
#                          omega 선례를 형태 블록에 적용. 정본 불변.
#   premise_null           전제검정 귀무를 농도내 라벨순열로 교체
#                          (작업 A-2/A-5). 중심화 경계 논증 대체.
#   volatility_fetch       PubChem 에서 증기압 후보값 수집. 판정 안 함.
#   volatility_space       휘발성 1차원 축 보조 분석. 본문 72검정
#                          가족과 분리된 사전지정 2검정 (V1/V2).
#   make_si_tables         SI 의 tab:ablation 을 산출물에서 생성. 종전에는
#                          10열 24수치를 손으로 유지하고 있었고, 그래서
#                          T2-1·T2-8 을 전부 통과해 구판으로 살아남았다.
#   sparse_indicators      희소 지시자 인코딩 민감도 + 논지 안정성 대조
# sparse_indicators 는 Mantel 전수열거를 세 변종에 돌리므로 약 10분 걸린다.
#   conformer_sensitivity  RDKit 매장 시드 6종 x 단일/앙상블. SI 가 두 예치물을
#                          이름 대어 인용하는데 2026-11-06 (9차) 까지 이 목록에
#                          없었다. 빈 outputs/ 로 클론하면 검증기 사전 점검에서
#                          멈춘다. dft_omega / xtb_fast 와 달리 제외 사유도
#                          재생성 명령도 적혀 있지 않았다.
# order_invariance 의 --n 40 은 반드시 명시해야 한다. 스크립트 기본값은 200
# 인데 예치본과 SI (S-meth:order 의 37 / 36 / 25 대 15) 는 40 회 결과다.
# 2026-11-06 (9차) 까지 인자 없이 호출하고 있어서, 예치된 사용법대로 돌린
# 독자는 SI 수치 네 개 중 세 개를 재현하지 못했다. 'distinct retained sets'
# 는 추첨 횟수에 따라 늘어나는 양이라 n 을 고정하지 않으면 뜻이 없다.
run_strict "order_invariance.py --n 40" match_rule_audit.py deltaE_noise.py \
           purity_sensitivity.py channel_classification.py \
           sparse_indicators.py multiplicity_panels.py \
           volatility_fetch.py volatility_space.py \
           shape_reduction.py premise_null.py conformer_sensitivity.py \
           make_si_tables.py

# dft_electronic_space.py 는 outputs/dft_omega.csv 와 outputs/dft_dipole.csv 를
# 읽는다. 둘은 B3LYP/def2-SVPD 28종 계산의 산출물이고 한 번에 약 54분 걸리므로
# 이 파이프라인에 넣지 않고 저장소에 커밋해 둔다. 재생성 명령을 여기 적는 것은
# 2026-10-25 에 겪은 고아 파일 사고를 되풀이하지 않기 위해서다.
#   python3 dft_omega.py                                 # -> outputs/dft_omega.*
#   python3 dft_omega.py --out outputs/dft_dipole        # -> 쌍극자 포함
# dft_electronic_space.py 는 두 파일의 궤도에너지가 1e-6 eV 안에서 일치하는지를
# 관문으로 검사하므로, 한쪽만 갱신하면 그 자리에서 멈춘다.

# 병리지수 제거 변종. 2026-10-25 까지 파이프라인에 없었다. 수동으로 한 번
# 돌린 산출물이 omega 제거 뒤에도 그대로 남아, 본문이 구판 값을 '모든 분석을
# 반복했다'며 인용했다. perm_nopatho.py 는 experiment_summary_nopatho.json 을
# 읽으므로 그 파일을 만든 뒤에 돌아야 한다. 그래서 위 목록에서 빼고 여기서
# 순서를 고정한다. 위 블록보다 앞에 두지 않는 이유는 analysis_main.py 본
# 실행이 접미사 없는 산출물을 먼저 써야 하기 때문이다.
run_strict_nopatho() {
  if ! python3 analysis_main.py --drop-pathological; then
    echo "[중단] analysis_main.py --drop-pathological 실패"; exit 1
  fi
  if ! python3 perm_nopatho.py; then
    echo "[중단] perm_nopatho.py 재실행 실패"; exit 1
  fi
}
run_strict_nopatho

# 독성축. parse -> trainset -> 동일성검사 -> QSAR 순서를 지켜야 한다.
run_strict parse_aegl.py build_tox_trainset.py cite_facts.py

# 동일성 검사는 보고서다. FAIL 2건(Pentaborane 구조 불일치, 다성분 레코드)은
# 원고가 제외했다고 적은 그 두 건이므로 비정상 종료로 파이프라인을 세우지
# 않는다. 다만 cwa_registry 가 이 산출물을 읽으므로 건너뛸 수는 없다.
printf '[run] %-22s ' validate_identity.py
if python3 validate_identity.py > outputs/_log_validate_identity.txt 2>&1; then
  echo 'ok (FAIL 0건)'
else
  echo "ok ($(grep -c '^   FAIL' outputs/_log_validate_identity.txt)건 보고 — 원고가 제외한 레코드)"
fi
[ -f outputs/identity_validation.json ] || { echo '  identity_validation.json 생성 실패'; exit 1; }

run_strict pca_facts.py qsar_tox.py h1_decoupling.py h1_screen_sensitivity.py \
           minority_regression.py validate_aegl_parse.py

# 다중검정 보정은 rollback_c 의 결과에서 파생된다.
python3 - <<'PY'
import json
import numpy as np
r = json.load(open('outputs/rollback_c.json'))
S = ['mean_diff', 'median_diff', 'mean_logratio', 'mean_dsim',
     'n_closer', 'n_valid']
rows = []
for lab, sp in r['panels'].items():
    ps = np.array([sp[s]['statistics'][k]['p'] for s in sp for k in S])
    o = np.sort(ps)
    m = len(o)
    bh = np.minimum.accumulate((o * m / np.arange(1, m + 1))[::-1])[::-1]
    rows.append((lab, m, float(o[0]), float(min(1, o[0] * m)), float(bh[0]),
                 int((bh < 0.05).sum())))
    print(f'  [BH] {lab:<38} 최소p {o[0]:.4f}  Bonferroni '
          f'{min(1, o[0]*m):.3f}  최소q {bh[0]:.3f}  q<0.05 {int((bh<0.05).sum())}건')
json.dump(rows, open('outputs/multiplicity_c.json', 'w'), indent=1)
PY

echo '[run] 완료. 다음: sh build_paper_acs.sh --figs && python3 verify_consistency.py'
